package zayfire.pocket_utilities;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_1792.class_1793;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 3, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0006\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001f\u0010\b\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0006H\u0002¢\u0006\u0004\b\b\u0010\tJ\r\u0010\u000b\u001a\u00020\n¢\u0006\u0004\b\u000b\u0010\u0003R\u0017\u0010\f\u001a\u00020\u00068\u0006¢\u0006\f\n\u0004\b\f\u0010\r\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u0010"},
   d2 = {"Lzayfire/pocket_utilities/ModItems;", "", "<init>", "()V", "", "name", "Lnet/minecraft/class_1792;", "item", "register", "(Ljava/lang/String;Lnet/minecraft/class_1792;)Lnet/minecraft/class_1792;", "", "registerAll", "POCKET_CRAFTING_TABLE", "Lnet/minecraft/class_1792;", "getPOCKET_CRAFTING_TABLE", "()Lnet/minecraft/class_1792;", "pocket-utilities"}
)
public final class ModItems {
   @NotNull
   public static final ModItems INSTANCE = new ModItems();
   @NotNull
   private static final class_1792 POCKET_CRAFTING_TABLE;

   private ModItems() {
   }

   @NotNull
   public final class_1792 getPOCKET_CRAFTING_TABLE() {
      return POCKET_CRAFTING_TABLE;
   }

   private final class_1792 register(String name, class_1792 item) {
      Object var10000 = class_2378.method_10230((class_2378)class_7923.field_41178, new class_2960("pocket-utilities", name), item);
      Intrinsics.checkNotNullExpressionValue(var10000, "register(...)");
      return (class_1792)var10000;
   }

   public final void registerAll() {
   }

   static {
      ModItems var10000 = INSTANCE;
      FabricItemSettings var10004 = (new FabricItemSettings()).maxCount(1);
      Intrinsics.checkNotNullExpressionValue(var10004, "maxCount(...)");
      POCKET_CRAFTING_TABLE = var10000.register("pocket_crafting_table", (class_1792)(new PocketCraftingItem((class_1793)var10004)));
   }
}

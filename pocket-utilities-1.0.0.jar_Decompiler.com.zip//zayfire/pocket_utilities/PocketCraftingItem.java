package zayfire.pocket_utilities;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1714;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3908;
import net.minecraft.class_747;
import net.minecraft.class_1792.class_1793;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 3, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J-\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\r0\f2\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\nH\u0016¢\u0006\u0004\b\u000e\u0010\u000f¨\u0006\u0010"},
   d2 = {"Lzayfire/pocket_utilities/PocketCraftingItem;", "Lnet/minecraft/class_1792;", "Lnet/minecraft/class_1792$class_1793;", "settings", "<init>", "(Lnet/minecraft/class_1792$class_1793;)V", "Lnet/minecraft/class_1937;", "world", "Lnet/minecraft/class_1657;", "player", "Lnet/minecraft/class_1268;", "hand", "Lnet/minecraft/class_1271;", "Lnet/minecraft/class_1799;", "use", "(Lnet/minecraft/class_1937;Lnet/minecraft/class_1657;Lnet/minecraft/class_1268;)Lnet/minecraft/class_1271;", "pocket-utilities"}
)
public final class PocketCraftingItem extends class_1792 {
   public PocketCraftingItem(@NotNull class_1793 settings) {
      Intrinsics.checkNotNullParameter(settings, "settings");
      super(settings);
   }

   @NotNull
   public class_1271<class_1799> method_7836(@NotNull class_1937 world, @NotNull class_1657 player, @NotNull class_1268 hand) {
      Intrinsics.checkNotNullParameter(world, "world");
      Intrinsics.checkNotNullParameter(player, "player");
      Intrinsics.checkNotNullParameter(hand, "hand");
      if (!world.field_9236) {
         player.method_17355((class_3908)(new class_747(PocketCraftingItem::use$lambda$0, (class_2561)class_2561.method_43471("container.crafting"))));
      }

      class_1271 var10000 = class_1271.method_22427(player.method_5998(hand));
      Intrinsics.checkNotNullExpressionValue(var10000, "success(...)");
      return var10000;
   }

   private static final class_1703 use$lambda$0(int syncId, class_1661 inv, class_1657 var2) {
      return (class_1703)(new class_1714(syncId, inv));
   }
}

package zayfire.pocket_utilities;

import kotlin.Metadata;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 3, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0005\u0010\u0003¨\u0006\u0006"},
   d2 = {"Lzayfire/pocket_utilities/PocketUtilitiesClient;", "Lnet/fabricmc/api/ClientModInitializer;", "<init>", "()V", "", "onInitializeClient", "pocket-utilities_client"}
)
@Environment(EnvType.CLIENT)
public final class PocketUtilitiesClient implements ClientModInitializer {
   @NotNull
   public static final PocketUtilitiesClient INSTANCE = new PocketUtilitiesClient();

   private PocketUtilitiesClient() {
   }

   public void onInitializeClient() {
   }
}

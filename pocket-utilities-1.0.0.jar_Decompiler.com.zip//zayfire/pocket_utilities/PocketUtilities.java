package zayfire.pocket_utilities;

import kotlin.Metadata;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroupEntries;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1935;
import net.minecraft.class_7706;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Metadata(
   mv = {2, 3, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0005\u0010\u0003R\u0014\u0010\u0007\u001a\u00020\u00068\u0006X\u0086T¢\u0006\u0006\n\u0004\b\u0007\u0010\bR\u001c\u0010\u000b\u001a\n \n*\u0004\u0018\u00010\t0\t8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000b\u0010\f¨\u0006\r"},
   d2 = {"Lzayfire/pocket_utilities/PocketUtilities;", "Lnet/fabricmc/api/ModInitializer;", "<init>", "()V", "", "onInitialize", "", "MOD_ID", "Ljava/lang/String;", "Lorg/slf4j/Logger;", "kotlin.jvm.PlatformType", "LOGGER", "Lorg/slf4j/Logger;", "pocket-utilities"}
)
public final class PocketUtilities implements ModInitializer {
   @NotNull
   public static final PocketUtilities INSTANCE = new PocketUtilities();
   @NotNull
   public static final String MOD_ID = "pocket-utilities";
   private static final Logger LOGGER = LoggerFactory.getLogger("pocket-utilities");

   private PocketUtilities() {
   }

   public void onInitialize() {
      ModItems.INSTANCE.registerAll();
      ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(PocketUtilities::onInitialize$lambda$0);
      LOGGER.info("Pocket Utilities loaded!");
   }

   private static final void onInitialize$lambda$0(FabricItemGroupEntries it) {
      it.method_45421((class_1935)ModItems.INSTANCE.getPOCKET_CRAFTING_TABLE());
   }
}
